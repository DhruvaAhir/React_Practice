import React, { useContext, useEffect, useRef, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { LoginContext } from '../context/loginContex'
import { UsersContext } from '../context/usersContext'
import { AppBar, Box, Button, Container, IconButton, Toolbar, Typography } from '@mui/material'

const Home = () => {
    const { loggedIn, setLoggedIn } = useContext(LoginContext)
    const { users, setUsers } = useContext(UsersContext)
    const [user, setUser] = useState({})
    const userRef = useRef(0)
    const navigate = useNavigate()
    useEffect(() => {
        if (loggedIn.loggedIn === false) {
            navigate('/login')
        } else {
            setUser(users.find(val => val.id === loggedIn.id))
            console.log(user)
        }
    }, [loggedIn])

    return (
        <Box sx={{ flexGrow: 1 }}>
            <AppBar position="static">
                <Toolbar>
                    <IconButton
                        size="large"
                        edge="start"
                        aria-label="menu"
                        sx={{ mr: 2 }}
                    >
                    </IconButton>
                    <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                        Home
                    </Typography>
                    <Button onClick={() => {
                        navigate('/login')
                    }} color="inherit">Login</Button >
                    <Button onClick={() => {
                        setLoggedIn({ loggedIn: false, email: null, id: null })
                    }} color="inherit">Logout</Button>
                </Toolbar>
            </AppBar>
            <Container>
                <h1>Hi {user.name}</h1>
            </Container>
        </Box>
    )
}

export default Home